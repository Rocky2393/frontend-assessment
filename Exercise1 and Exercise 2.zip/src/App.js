import { useState } from "react";
import "./App.css";
import cardImage from "./images/content-img.png";

function App() {
  const [activeAccordion, setActiveAccordion] = useState(0);
  const cardContent = [
    {
      title: "Item 1",
      content:
        "Maecenas nec semper ante, pellentesque posuere lorem. Nullam ipsum massa, consequat eget urna ut, pulvinar dignissim lorem. Nulla facilisi. Nam mattis eleifend metus. Fusce at commodo lorem. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Phasellus pellentesque elit sem, vel blandit posuere.",
    },
    {
      title: "Item 2",
      content:
        "Mauris a orci sodales, scelerisque velit vitae, gravida nisl. Ut non laoreet eros, vel laoreet nisi. Praesent sed dolor dui. Proin non fringilla quam. Aliquam erat volutpat. Vestibulum vel arcu semper, lobortis turpis ac, ultricies nisi. Praesent id.",
    },
    {
      title: "Item 3",
      content:
        "Sed elementum sapien ut sapien imperdiet, eu venenatis enim rhoncus. Praesent euismod tincidunt rhoncus. Duis cras amet:\n- List item one\n- List item two\n- List item three",
    },
  ];

  const tabContent = [
    {
      title: "Item 1",
      content:
        "Maecenas nec semper ante, pellentesque posuere lorem. Nullam ipsum massa, consequat eget urna ut, pulvinar dignissim lorem. Nulla facilisi. Nam mattis eleifend metus. Fusce at commodo lorem. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Phasellus pellentesque elit sem, vel blandit posuere.",
    },
    {
      title: "Item 2",
      content:
        "Mauris a orci sodales, scelerisque velit vitae, gravida nisl. Ut non laoreet eros, vel laoreet nisi. Praesent sed dolor dui. Proin non fringilla quam. Aliquam erat volutpat. Vestibulum vel arcu semper, lobortis turpis ac, ultricies nisi. Praesent id.",
    },
    {
      title: "Item 3",
      content:
        "Sed elementum sapien ut sapien imperdiet, eu venenatis enim rhoncus. Praesent euismod tincidunt rhoncus. Duis cras amet:\n- List item one\n- List item two\n- List item three",
    },
  ];

  return (
    <>
      <div className="container-fluid">
        <div className="header-banner">
          <div className="overlay"></div>
          <h2>Hello Developer</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
        </div>

        <div className="card-section">
          {cardContent.map((card, index) => (
            <div className="card" key={index}>
              <img
                src={cardImage}
                className="card-img-top"
                alt={`Image ${index + 1}`}
              />
              <div className="card-body">
                <h5 className="card-title">{card.title}</h5>
                <p className="card-text">{card.content}</p>
                <a href="#" className="btn btn-primary">
                  Read More
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>

      <h1 className="exercise2">Exercise 2</h1>

      <div className="container mb-5 myTabs">
        <div className="row">
          <div className="col-sm-8 mx-auto">
            <ul className="nav nav-tabs mb-3" id="ex1" role="tablist">
              {tabContent.map((tab, index) => (
                <li className="nav-item" role="presentation" key={index}>
                  <a
                    className={`nav-link ${index === 0 ? "active" : ""}`}
                    id={`ex1-tab-${index + 1}`}
                    data-bs-toggle="tab"
                    href={`#ex1-tabs-${index + 1}`}
                    role="tab"
                    aria-controls={`ex1-tabs-${index + 1}`}
                    aria-selected={index === 0 ? "true" : "false"}
                  >
                    {tab.title}
                  </a>
                </li>
              ))}
            </ul>
            <div className="tab-content" id="ex1-content">
              {tabContent.map((tab, index) => (
                <div
                  className={`tab-pane fade ${
                    index === 0 ? "show active" : ""
                  } my-tab-content`}
                  id={`ex1-tabs-${index + 1}`}
                  role="tabpanel"
                  aria-labelledby={`ex1-tab-${index + 1}`}
                  key={index}
                >
                  {tab.content}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="container  mb-5 myAccordians">
        <div className="row">
          <div className="col-sm-8 mx-auto">
            
            <div className="accordion" id="accordionExample">
              {tabContent.map((tab, index) => (
                <div className="accordion-item" key={index}>
                  <h2 className="accordion-header">
                    <button
                      className={`accordion-button ${
                        activeAccordion === index ? "" : "collapsed"
                      }`}
                      type="button"
                      onClick={() =>
                        setActiveAccordion(
                          activeAccordion === index ? -1 : index
                        )
                      }
                    >
                      {tab.title}
                    </button>
                  </h2>
                  <div
                    id={`collapse-${index}`}
                    className={`accordion-collapse collapse ${
                      activeAccordion === index ? "show" : ""
                    }`}
                    aria-labelledby={`heading-${index}`}
                    data-bs-parent="#accordionExample"
                  >
                    <div className="accordion-body">{tab.content}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
